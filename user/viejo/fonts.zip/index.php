<?php
include "../config/conection.php";

if(!isset($ref)){

redir("../");

}

if(isset($_GET['ref']) && $_GET['ref']!="")
{
	if(nombre_apellido_usuario($_GET['ref']) != "0")
	{
		$ref = $_GET['ref'];
	
		if(file_exists("../img/avatares/".$ref.".jpg"))
		{
			$avatar = $ref.".jpg";
			$usuario = "<font color='white' style='position:relative;top:10px;'>".nombre_apellido_usuario($ref)."</font>";
			$foto="<img  style='display:inline-block;width:35px;height:35px;position:relative;top:10px;border-radius:50%;' src='../img/avatares/".$avatar."'/>";
		}
		else
		{
			$usuario = "<font color='white' style='position:relative;top:10px;'>".nombre_apellido_usuario($ref)."</font>";
			$foto="<img  style='display:inline-block;width:35px;height:35px;position:relative;top:10px; border-radius:50%;' src='../img/avatares/0.png'/>";


		}
	}
		
}
?>
<!DOCTYPE html>
<!DOCTYPE HTML>
<!--
	Industrious by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<html lang="es-ES"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Flowerful</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="../../assets/css/main.css" />
		<link rel="icon" href="http://promoliderv.org/img/iso.png" />


<body>
		<!-- Header -->
		<header id="header">
			<a class="logo" href="http://promoliderv.org">Flowerful</a>
			<nav>
				<a href="#menu">Menu</a>
			</nav>
		</header>

	<!-- Nav -->
		<nav id="menu">
			<ul class="links">
			    <li><a href="#" style="text-align:center;"><?=$foto?></a></li>
				<li><a href="#" style="text-align:center;"><?=$usuario?></a></li>
				<li><a href="../register/?ref=<?=$ref?>" style="text-align:center;">Registrate</a></li>
				<li><a href="http://promoliderv.org/login.php" style="text-align:center;">Login</a></li>
			</ul>
		</nav>

		<!-- Banner -->
			<section id="banner">
				<div class="inner">
					<h1>Flowerful</h1>
					<p>¡ELEVA TU ÉXITO!</p>
				</div>
				<video autoplay loop muted playsinline src="../../images/banner.mp4"></video>
			</section>

		<!-- Highlights -->
			<section class="wrapper">
				<div class="inner">
					<header class="special">
						<h2>¿Por qué unirte a Flowerful?</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum cumque, veniam ducimus commodi, harum quis cupiditate nesciunt assumenda a iusto modi corporis beatae eum blanditiis nisi nulla, vero consequatur eos..</p>
					</header>
					<div class="highlights">
						<section>
							<div class="content">
								<header>
									<a href="#" class="icon fa-line-chart"><span class="label">Icon</span></a>
									<h3>RENTABILIDAD</h3>
								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta, esse? Veniam aperiam similique fugit sint, maxime illo magnam voluptatem expedita obcaecati harum laborum tenetur nam impedit atque, cum corporis repellat..</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="#" class="icon fa-paper-plane-o"><span class="label">Icon</span></a>
									<h3>OBJETIVO</h3>
								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi provident nostrum in, quibusdam sint commodi, laudantium. Quod vero dolore neque, reiciendis id nisi qui placeat consectetur magni eos illo. Ad?</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="#" class="icon fa-vcard-o"><span class="label">Icon</span></a>
									<h3>CONFIANZA</h3>
								</header>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus incidunt sit mollitia consequatur inventore nisi consectetur, magni fugiat debitis enim! Obcaecati modi sit adipisci nostrum, corporis consequatur ullam eligendi iusto..</p>
							</div>
						</section>
					</div>
				</div>
			</section>

		<!-- CTA -->
			<section id="cta" class="wrapper">
				<div class="inner">
					<h2>Visión</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quae veniam repellendus explicabo perspiciatis odit vero, deserunt, dignissimos delectus provident reprehenderit, distinctio consequatur nostrum maiores unde expedita quos porro, necessitatibus animi..</p>
				</div>
			</section>

		<!-- Testimonials -->
			<section class="wrapper">
				<div class="inner">
					<header class="special">
						<h2>TEAM FLOWERFUL</h2>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima impedit accusamus, odit eius ducimus nisi eos culpa, veritatis a fugit doloremque, vel ipsa fuga pariatur tenetur rem, voluptatum id consectetur.
						</p>
					</header>
					<div class="testimonials">
						<section>
							<div class="content">
								<blockquote>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim omnis, consectetur cumque vel, corporis asperiores exercitationem maxime</p>
								</blockquote>
								<div class="author">
									<div class="image">
										<img src="../../images/pic01.jpg" alt="" />
									</div>
									<p class="credit">- <strong>Lorena chu</strong> <span>CEO - flowerful.</span></p>
								</div>
							</div>
						</section>
						<section>
							<div class="content">
								<blockquote>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim omnis, consectetur cumque vel, corporis asperiores exercitationem maxime .</p>
								</blockquote>
								<div class="author">
									<div class="image">
										<img src="../../images/pic03.jpg" alt="" />
									</div>
									<p class="credit">- <strong>Raul santino</strong> <span>CEO - flowerful.</span></p>
								</div>
							</div>
						</section>
						<section>
							<div class="content">
								<blockquote>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim omnis, consectetur cumque vel, corporis asperiores exercitationem maxime!</p>
								</blockquote>
								<div class="author">
									<div class="image">
										<img src="../../images/pic02.jpg" alt="" />
									</div>
									<p class="credit">- <strong>Janet Smith</strong> <span>CEO - flowerful.</span></p>
								</div>
							</div>
						</section>
					</div>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<div class="content">
						<section>
							<h3>Acerca de Flowerful</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Hic provident odit rerum possimus, laudantium eaque maxime totam aliquam ipsum. Error totam, iusto rerum dolorum, adipisci ut quod quisquam laudantium culpa?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel rem modi consequatur, nisi dolorum deleniti sunt officiis quis labore molestias voluptatum officia natus corporis libero consectetur, dolor nobis, id nostrum..</p>
						</section>
						<section>
							<h4>Mapa de navegación</h4>
							<ul class="alt">
								<li><a href="#">Home.</a></li>
								<li><a href="#">Blog.</a></li>
								<li><a href="#">Contacto.</a></li>
								<li><a href="#">Login.</a></li>
							</ul>
						</section>
						<section>
							<h4>Magna sed ipsum</h4>
							<ul class="plain">
								<li><a href="#"><i class="icon fa-twitter">&nbsp;</i>Twitter</a></li>
								<li><a href="#"><i class="icon fa-facebook">&nbsp;</i>Facebook</a></li>
								<li><a href="#"><i class="icon fa-instagram">&nbsp;</i>Instagram</a></li>
							</ul>
						</section>
					</div>
					<div class="copyright">
						&copy; Flowerful (cpz).
					</div>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="../../assets/js/jquery.min.js"></script>
			<script src="../../assets/js/browser.min.js"></script>
			<script src="../../assets/js/breakpoints.min.js"></script>
			<script src="../../assets/js/util.js"></script>
			<script src="../../assets/js/main.js"></script>

	</body>
</html>
